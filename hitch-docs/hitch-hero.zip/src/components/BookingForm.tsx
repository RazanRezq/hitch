import { useMemo, useState } from "react";
import { ArrowRight, Plane, MapPin, Clock, Users, Repeat, Calendar as CalIcon } from "lucide-react";

type TripType = "one-way" | "round" | "hourly";

const LOCATIONS: Record<string, number> = {
  "Reykjavík city center": 49,
  "Blue Lagoon": 22,
  "Vík í Mýrdal": 187,
  "Akureyri": 388,
  "Selfoss": 75,
  "Hveragerði": 60,
  "Geysir / Golden Circle": 110,
  "Jökulsárlón": 379,
};

const AIRPORTS = ["KEF · Keflavík Airport", "RKV · Reykjavík Domestic", "AEY · Akureyri Airport"];

// Pricing model (ISK)
const BASE_FARE = 4500;
const PER_KM = 285;
const NIGHT_SURCHARGE = 1.15; // 22:00–06:00
const ROUND_MULT = 1.85;
const HOURLY_RATE = 14900;

function formatISK(n: number) {
  return new Intl.NumberFormat("is-IS", { maximumFractionDigits: 0 }).format(Math.round(n)) + " ISK";
}

function todayStr() {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
}

export function BookingForm() {
  const [trip, setTrip] = useState<TripType>("one-way");
  const [from, setFrom] = useState(AIRPORTS[0]);
  const [to, setTo] = useState<string>("Reykjavík city center");
  const [date, setDate] = useState(todayStr());
  const [time, setTime] = useState("14:30");
  const [pax, setPax] = useState(2);
  const [hours, setHours] = useState(3);

  const { distance, price, eta } = useMemo(() => {
    const km = LOCATIONS[to] ?? 49;
    const hour = parseInt(time.split(":")[0] || "12", 10);
    const isNight = hour >= 22 || hour < 6;
    const paxMult = pax > 4 ? 1.25 : 1;

    let p: number;
    if (trip === "hourly") {
      p = HOURLY_RATE * hours * paxMult;
    } else {
      p = (BASE_FARE + km * PER_KM) * paxMult;
      if (trip === "round") p *= ROUND_MULT;
    }
    if (isNight) p *= NIGHT_SURCHARGE;

    const etaMin = trip === "hourly" ? hours * 60 : Math.round(km * 0.95);
    return { distance: km, price: p, eta: etaMin };
  }, [trip, to, time, pax, hours, trip]);

  const tabs: { id: TripType; label: string; icon: React.ReactNode }[] = [
    { id: "one-way", label: "One-way", icon: <ArrowRight className="h-3.5 w-3.5" /> },
    { id: "round", label: "Round trip", icon: <Repeat className="h-3.5 w-3.5" /> },
    { id: "hourly", label: "Hourly", icon: <Clock className="h-3.5 w-3.5" /> },
  ];

  return (
    <div className="rounded-3xl border border-white/10 bg-white/[0.06] p-2 backdrop-blur-xl">
      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-1 px-2 pt-2">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTrip(t.id)}
            className={`inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-sm transition ${
              trip === t.id
                ? "bg-white text-[oklch(0.15_0.04_260)]"
                : "text-white/70 hover:text-white"
            }`}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
      </div>

      {/* Fields */}
      <div className="mt-2 grid grid-cols-1 gap-px overflow-hidden rounded-2xl bg-white/5 md:grid-cols-2 lg:grid-cols-[1.1fr_1.1fr_0.9fr_0.7fr_auto]">
        <Field icon={<Plane className="h-4 w-4" />} label="From">
          <select
            value={from}
            onChange={(e) => setFrom(e.target.value)}
            className="w-full bg-transparent text-base text-white outline-none"
          >
            {AIRPORTS.map((a) => (
              <option key={a} value={a} className="bg-[oklch(0.15_0.04_260)]">
                {a}
              </option>
            ))}
          </select>
        </Field>

        <Field icon={<MapPin className="h-4 w-4" />} label={trip === "hourly" ? "Area" : "To"}>
          <select
            value={to}
            onChange={(e) => setTo(e.target.value)}
            className="w-full bg-transparent text-base text-white outline-none"
          >
            {Object.keys(LOCATIONS).map((l) => (
              <option key={l} value={l} className="bg-[oklch(0.15_0.04_260)]">
                {l}
              </option>
            ))}
          </select>
        </Field>

        <Field icon={<CalIcon className="h-4 w-4" />} label="Date">
          <input
            type="date"
            value={date}
            min={todayStr()}
            onChange={(e) => setDate(e.target.value)}
            className="w-full bg-transparent text-base text-white outline-none [color-scheme:dark]"
          />
        </Field>

        {trip === "hourly" ? (
          <Field icon={<Clock className="h-4 w-4" />} label="Hours">
            <input
              type="number"
              min={2}
              max={12}
              value={hours}
              onChange={(e) => setHours(Math.max(2, Math.min(12, +e.target.value || 2)))}
              className="w-full bg-transparent text-base text-white outline-none"
            />
          </Field>
        ) : (
          <Field icon={<Clock className="h-4 w-4" />} label="Time">
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-full bg-transparent text-base text-white outline-none [color-scheme:dark]"
            />
          </Field>
        )}

        <button
          type="button"
          className="group flex items-center justify-center gap-2 bg-gradient-to-r from-[oklch(0.85_0.18_165)] to-[oklch(0.78_0.15_200)] px-6 py-5 text-sm font-medium text-[oklch(0.15_0.04_260)] transition hover:opacity-90"
        >
          Reserve
          <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
        </button>
      </div>

      {/* Pax + estimate */}
      <div className="mt-3 flex flex-col gap-3 px-3 pb-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 text-[11px] uppercase tracking-widest text-white/50">
            <Users className="h-3.5 w-3.5" /> Passengers
          </span>
          <div className="flex items-center gap-1 rounded-full border border-white/10 bg-white/5 p-1">
            <button
              type="button"
              onClick={() => setPax(Math.max(1, pax - 1))}
              className="h-7 w-7 rounded-full text-white/80 hover:bg-white/10"
              aria-label="Fewer passengers"
            >
              −
            </button>
            <span className="w-6 text-center text-sm tabular-nums text-white">{pax}</span>
            <button
              type="button"
              onClick={() => setPax(Math.min(8, pax + 1))}
              className="h-7 w-7 rounded-full text-white/80 hover:bg-white/10"
              aria-label="More passengers"
            >
              +
            </button>
          </div>
          {pax > 4 && (
            <span className="text-[11px] uppercase tracking-widest text-white/50">
              · Premium van
            </span>
          )}
        </div>

        <div className="flex items-center gap-5 rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5">
          <div className="flex flex-col">
            <span className="text-[10px] uppercase tracking-widest text-white/50">
              {trip === "hourly" ? "Duration" : "Distance"}
            </span>
            <span className="text-sm text-white tabular-nums">
              {trip === "hourly" ? `${hours} h` : `${distance} km · ~${eta} min`}
            </span>
          </div>
          <div className="h-8 w-px bg-white/10" />
          <div className="flex flex-col">
            <span className="text-[10px] uppercase tracking-widest text-white/50">
              Fixed fare
            </span>
            <span className="font-display text-lg leading-none text-aurora tabular-nums">
              {formatISK(price)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({
  icon,
  label,
  children,
}: {
  icon: React.ReactNode;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1 bg-[oklch(0.18_0.04_260)/0.6] px-5 py-4 transition hover:bg-[oklch(0.22_0.04_260)/0.6]">
      <span className="flex items-center gap-2 text-[11px] uppercase tracking-widest text-white/50">
        {icon} {label}
      </span>
      {children}
    </label>
  );
}
