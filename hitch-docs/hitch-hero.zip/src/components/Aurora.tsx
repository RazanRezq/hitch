export function Aurora() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {/* Aurora glow blobs */}
      <div
        className="aurora-layer-1 absolute -top-1/4 left-[-10%] h-[80vh] w-[90vw] rounded-full opacity-70 blur-3xl"
        style={{
          background:
            "radial-gradient(closest-side, oklch(0.85 0.18 165 / 0.55), transparent 70%)",
        }}
      />
      <div
        className="aurora-layer-2 absolute top-[10%] right-[-15%] h-[70vh] w-[80vw] rounded-full opacity-70 blur-3xl"
        style={{
          background:
            "radial-gradient(closest-side, oklch(0.78 0.15 200 / 0.5), transparent 70%)",
        }}
      />
      <div
        className="aurora-layer-1 absolute top-[5%] left-[20%] h-[60vh] w-[60vw] rounded-full opacity-60 blur-3xl"
        style={{
          background:
            "radial-gradient(closest-side, oklch(0.82 0.12 290 / 0.45), transparent 70%)",
          animationDuration: "22s",
        }}
      />
    </div>
  );
}
