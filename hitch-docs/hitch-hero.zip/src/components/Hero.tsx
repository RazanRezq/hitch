import { ArrowRight } from "lucide-react";
import auroraBg from "@/assets/aurora-hero.jpg";
import { Aurora } from "./Aurora";
import { Stars } from "./Stars";
import { BookingForm } from "./BookingForm";

export function Hero() {
  return (
    <section className="relative min-h-screen w-full overflow-hidden bg-[oklch(0.12_0.04_260)] text-white">
      {/* Background image */}
      <img
        src={auroraBg}
        alt="Aurora over Iceland"
        width={1920}
        height={1080}
        className="bg-slow-zoom absolute inset-0 h-full w-full object-cover opacity-90"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[oklch(0.12_0.04_260)/0.3] via-transparent to-[oklch(0.10_0.04_260)]" />

      {/* Animated aurora overlays */}
      <Aurora />
      <Stars />

      {/* Top status bar */}
      <div className="relative z-20 mx-auto flex max-w-[1400px] items-center justify-between px-6 pt-5 text-[11px] uppercase tracking-[0.18em] text-white/60">
        <div className="hidden items-center gap-5 md:flex">
          <span>Reykjavík</span>
          <span>64.13°N · 21.94°W</span>
          <span>12:48 LOCAL</span>
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_oklch(0.85_0.18_165)]" />
            37 cars on shift
          </span>
        </div>
        <div className="hidden items-center gap-5 md:flex">
          <span>CH 02 · Arrivals</span>
          <span>+354 619 1819</span>
        </div>
      </div>

      {/* Nav */}
      <header className="relative z-20 mx-auto mt-4 flex max-w-[1400px] items-center justify-between px-6 py-4">
        <a href="/" className="font-display text-2xl tracking-tight">
          H<span className="font-display-italic mx-0.5">i</span>tch
        </a>
        <nav className="hidden items-center gap-8 text-sm text-white/80 md:flex">
          <a href="#fly" className="border-b border-white pb-0.5 text-white">Fly</a>
          <a href="#fleet" className="hover:text-white">Fleet</a>
          <a href="#coverage" className="hover:text-white">Coverage</a>
          <a href="#stories" className="hover:text-white">Stories</a>
        </nav>
        <div className="flex items-center gap-4">
          <div className="hidden items-center gap-3 text-xs uppercase tracking-widest text-white/60 lg:flex">
            <span>ISK</span><span>EUR</span><span className="text-white">USD</span>
            <span className="mx-2 h-3 w-px bg-white/20" />
            <span>IS</span><span className="text-white">EN</span><span>AR</span>
          </div>
          <a href="#signin" className="hidden text-sm text-white/80 hover:text-white sm:inline">Sign in</a>
          <a
            href="#book"
            className="group inline-flex items-center gap-2 rounded-full bg-white px-5 py-2.5 text-sm font-medium text-[oklch(0.15_0.04_260)] transition hover:bg-white/90"
          >
            Book now
            <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
          </a>
        </div>
      </header>

      {/* Headline */}
      <div className="relative z-10 mx-auto max-w-[1400px] px-6 pt-16 md:pt-24">
        <h1 className="font-display text-[clamp(4rem,12vw,11rem)] leading-[0.92]">
          <span className="block">Land.</span>
          <span className="font-display-italic block text-aurora">Hitch.</span>
          <span className="block">Home.</span>
        </h1>
        <p className="mt-8 max-w-md text-base text-white/70 md:text-lg">
          The final leg of your journey — perfected. Fixed fare, personal driver,
          exactly at the gate.
        </p>
      </div>

      {/* Booking card */}
      <div className="relative z-20 mx-auto mt-20 max-w-[1400px] px-6 pb-12">
        <BookingForm />

        <div className="mt-8 grid grid-cols-2 gap-6 text-sm text-white/60 md:grid-cols-4">
          <Stat k="14 min" v="Avg pickup at KEF" />
          <Stat k="100%" v="Fixed fare, no surge" />
          <Stat k="4.96★" v="From 12,400 riders" />
          <Stat k="24/7" v="Year-round, any weather" />
        </div>
      </div>
    </section>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <div className="font-display text-2xl text-white">{k}</div>
      <div className="mt-1 text-xs uppercase tracking-widest">{v}</div>
    </div>
  );
}
