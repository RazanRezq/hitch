import { createFileRoute } from "@tanstack/react-router";
import { Hero } from "@/components/Hero";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Hitch — Premium Airport Transfers in Iceland" },
      {
        name: "description",
        content:
          "Hitch: fixed-fare, premium airport transfers across Iceland. Meet your driver at the gate. KEF to anywhere, 24/7.",
      },
    ],
  }),
});

function Index() {
  return (
    <main>
      <Hero />
    </main>
  );
}
